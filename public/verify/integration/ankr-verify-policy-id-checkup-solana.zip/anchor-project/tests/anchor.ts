import * as anchor from "@coral-xyz/anchor";
import type {PolicyRepo} from "../target/types/policy_repo";
import type {IntegrationExample} from "../target/types/integration_example";
import {assert} from "chai";
import * as borsh from "borsh";

import {ConfirmOptions, PublicKey} from "@solana/web3.js";

const POLICY_ID = new anchor.BN(10);
const CID = "1234";
const USER_KEY = anchor.web3.Keypair.generate();
const USER = USER_KEY.publicKey;
const confirmOptions: ConfirmOptions = {commitment: "confirmed"};

// Deserialize the struct and validate
class Assignable {
    constructor(properties) {
        Object.keys(properties).map((key) => {
            this[key] = properties[key];
        });
    }
}

class Data extends Assignable {
}

function numToUint8Array(num) {
    let arr = new Uint8Array(8);

    for (let i = 0; i < 8; i++) {
        arr[i] = num % 256;
        num = Math.floor(num / 256);
    }

    return arr;
}

function getReturnLog(tx) {
    const prefix = "Program return: ";
    let log = tx.meta.logMessages.find((log) =>
        log.startsWith(prefix)
    );
    log = log.slice(prefix.length);
    const [key, data] = log.split(" ", 2);
    const buffer = Buffer.from(data, "base64");
    return [key, data, buffer];
}

describe("Test policy repo integration", () => {
    // Configure the client to use the local cluster
    anchor.setProvider(anchor.AnchorProvider.env());

    const policyRepo = anchor.workspace.PolicyRepo as anchor.Program<PolicyRepo>;
    const integrationExample = anchor.workspace.IntegrationExample as anchor.Program<IntegrationExample>;

    let CID_PDA

    it("add policy", async () => {
        [PDA] = anchor.web3.PublicKey.findProgramAddressSync(
            [
                USER.toBuffer(),
                POLICY_ID.toArrayLike(Buffer, "le", 8)
            ],
            policyRepo.programId
        );
        let tx = await policyRepo.methods
            .addPolicy(
                USER,
                POLICY_ID,
                CID,
            )
            .accounts({policy: CID_PDA})
            .rpc();
        let latestBlockhash = await policyRepo.provider.connection.getLatestBlockhash('finalized');
        await policyRepo.provider.connection.confirmTransaction({
            signature: tx,
            blockhash: latestBlockhash.blockhash,
            lastValidBlockHeight: latestBlockhash.lastValidBlockHeight
        });
    });

    it("fetch data from pda", async () => {
        const data = await policyRepo.account.policy.fetch(CID_PDA);
        assert.equal(data.cid, CID, "cid is not equal default")
        assert.equal(data.policyId.toNumber(), POLICY_ID.toNumber(), "policy is not eq default")
        assert.equal(data.user.toBase58(), USER.toBase58(), "user is not eq default")
    });

    it("get policy directly", async () => {
        const data = await policyRepo.account.policy.fetch(CID_PDA);
        let result = await policyRepo.methods.getPolicy().accounts({account: CID_PDA}).view();
        assert.equal(data.cid, result.cid, "cids are not equal")
        assert.equal(data.policyId.toNumber(), result.policyId.toNumber(), "policy ids are not equal")
        assert.equal(data.user.toBase58(), result.user.toBase58(), "users are not equal")
    });

    it("get policy in cpi", async () => {
        const tx = await integrationExample.methods
            .doTask()
            .accounts({
                cpiPolicy: CID_PDA,
                cpiPolicyRepoProgram: policyRepo.programId,
            })
            .rpc(confirmOptions);
        let t = await integrationExample.provider.connection.getTransaction(tx, {
            commitment: "confirmed",
        });
        const [key, data, buffer] = getReturnLog(t);
        assert.equal(key, policyRepo.programId);
        let receiveLog = t.meta.logMessages.find(
            (log) => log == `Program data: ${data}`
        );
        assert(receiveLog !== undefined);
        const schema = new Map([
            [Data, {kind: "struct", fields: [["cid", "string"], ["policy_id", "u64"], ["user", [32]]]}],
        ]);

        const deserialized = borsh.deserialize(schema, Data, buffer);
        assert.equal(deserialized.cid, CID, "cid is not equal default")
        assert.equal(deserialized.policy_id.toNumber(), POLICY_ID.toNumber(), "policy is not eq default")
        assert.equal(deserialized.user.toString(), USER.toBytes().toString(), "user is not eq default")
    });
});