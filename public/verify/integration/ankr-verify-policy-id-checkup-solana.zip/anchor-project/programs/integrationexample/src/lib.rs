use anchor_lang::prelude::*;
use policy_repo::cpi::accounts::PolicyReturn;
use policy_repo::program::PolicyRepo;
use policy_repo::{self, Policy};


declare_id!("3LXM7dnUyFiUPaxnv9TH1pwrzod46RYD8KyxKbCkDPP9");

#[program]
pub mod integration_example {
    use super::*;

    pub fn do_task(ctx: Context<CpiReturnContext>) -> Result<()> {
        let cpi_program = ctx.accounts.cpi_policy_repo_program.to_account_info();
        let cpi_account = PolicyReturn { account: ctx.accounts.cpi_policy.to_account_info() };
        let cpi_ctx = CpiContext::new(cpi_program, cpi_account);
        let result = policy_repo::cpi::get_policy(cpi_ctx)?;
        let solana_return = result.get();

        assert!(solana_return.policy_id == 10);

        anchor_lang::solana_program::log::sol_log_data(&[&solana_return.try_to_vec().unwrap()]);
        Ok(())
    }
}

#[derive(Accounts)]
pub struct CpiReturnContext<'info> {
    #[account(mut)]
    pub cpi_policy: Account<'info, Policy>,
    pub cpi_policy_repo_program: Program<'info, PolicyRepo>,
}
