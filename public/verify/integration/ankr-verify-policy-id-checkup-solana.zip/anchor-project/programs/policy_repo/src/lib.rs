use anchor_lang::prelude::*;
use solana_program::{pubkey};

declare_id!("4yrFxst43upUzQuJB8jJ2XH58FXQ3d9x98vuDAtEwC5Q");
const ADMIN_PUBKEY: Pubkey = pubkey!("9AZct21CAFPGiLUYAh7WsqSviYN1R3c76gPuw5EBwJ7p");

#[program]
mod policy_repo {
    use super::*;

    pub fn get_policy(ctx: Context<PolicyReturn>) -> Result<Policy> {
        msg!("Attempting to return policy with ID");
        let policy = &ctx.accounts.account;
        msg!("Policy: {}", policy.policy_id);
        Ok(Policy {
            cid: policy.cid.clone(),
            policy_id: policy.policy_id,
            user: policy.user,
        })
    }

    pub fn add_policy(ctx: Context<CreatePolicy>, user: Pubkey, policy_id: u64, cid: String) -> Result<()> {
        let new_policy = &mut ctx.accounts.policy;
        new_policy.cid = cid.clone();
        new_policy.policy_id = policy_id;
        new_policy.user = user;
        msg!("Policy: {}", policy_id);
        msg!("User: {}", user);
        msg!("CID: {}", cid);
        Ok(())
    }
}

#[account]
pub struct Policy {
    pub cid: String,
    pub policy_id: u64,
    pub user: Pubkey,
}

#[derive(Accounts)]
#[instruction(user: Pubkey, policy_id: u64)]
pub struct CreatePolicy<'info> {
    #[account(
    mut,
    address = ADMIN_PUBKEY
    )]
    pub admin: Signer<'info>,

    #[account(
    init_if_needed,
    payer = signer,
    space = 500,
    seeds = [user.as_ref(), & policy_id.to_le_bytes()],
    bump
    )]
    pub policy: Account<'info, Policy>,
    #[account(mut)]
    pub signer: Signer<'info>,
    pub system_program: Program<'info, System>,
}


#[derive(Accounts)]
pub struct PolicyReturn<'info> {
    pub account: Account<'info, Policy>,
}

